# Automotive Spare Parts - Frontend

A modern, responsive React.js frontend for an automotive spare parts e-commerce platform built with Vite, Tailwind CSS, and React Router.

## 🚀 Features

- **Modern UI/UX**: Clean, responsive design with Tailwind CSS
- **Car Search Interface**: Advanced car search with cascading dropdowns
- **Product Catalog**: Comprehensive product browsing and filtering
- **User Authentication**: Secure login and registration system
- **Shopping Cart**: Full cart functionality with item management
- **Order Management**: Complete order tracking and history
- **User Profile**: Comprehensive user profile management
- **Multi-language Support**: Internationalization ready
- **Mobile Responsive**: Optimized for all device sizes
- **Admin Dashboard**: Full admin panel integration

## 🛠️ Tech Stack

- **Framework**: React 18 with Hooks
- **Build Tool**: Vite (fast development and building)
- **Styling**: Tailwind CSS with custom components
- **Routing**: React Router v5
- **State Management**: React Context API + Redux
- **Icons**: React Icons (Font Awesome, Material Design)
- **HTTP Client**: Axios for API communication
- **Form Handling**: React Hook Form
- **Notifications**: React Toastify
- **Charts**: Recharts for analytics
- **Authentication**: JWT token-based authentication

## 📁 Project Structure

```
Admin/
├── public/                     # Static assets
│   ├── favicon.ico
│   ├── logo192.png
│   └── manifest.json
├── src/
│   ├── components/             # Reusable UI components
│   │   ├── forms/             # Form components
│   │   ├── tables/             # Table components
│   │   ├── charts/             # Chart components
│   │   └── ...
│   ├── context/                # React Context providers
│   │   ├── AdminContext.jsx    # Admin state management
│   │   ├── SidebarContext.jsx  # Sidebar state
│   │   └── ThemeContext.js     # Theme management
│   ├── hooks/                  # Custom React hooks
│   ├── layout/                 # Layout components
│   │   ├── Layout.jsx           # Main layout wrapper
│   │   ├── Main.jsx            # Main content area
│   │   └── Localization.jsx     # Language support
│   ├── pages/                  # Page components
│   │   ├── HomePage.jsx        # Home page with car search
│   │   ├── Garage.jsx          # My Garage page
│   │   ├── MyProfile.jsx       # User profile page
│   │   ├── MyOrder.jsx         # Order history page
│   │   ├── MyWishlist.jsx      # Wishlist page
│   │   ├── Addresses.jsx       # Address management
│   │   ├── CompanyGST.jsx      # Business information
│   │   ├── Document.jsx        # Document management
│   │   └── Cart.jsx            # Shopping cart
│   ├── routes/                 # Routing configuration
│   │   ├── index.js            # Route definitions
│   │   └── sidebar.js          # Sidebar navigation
│   ├── services/               # API service functions
│   ├── utils/                  # Utility functions
│   ├── assets/                 # Static assets
│   │   ├── css/                # Custom CSS files
│   │   ├── img/                # Images and icons
│   │   └── theme/              # Theme configurations
│   ├── reduxStore/             # Redux store configuration
│   ├── App.jsx                 # Main app component
│   └── main.jsx                # Application entry point
├── package.json
├── vite.config.js              # Vite configuration
├── tailwind.config.js          # Tailwind CSS configuration
└── vercel.json                 # Deployment configuration
```

## 🚀 Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-frontend-repo-url>
   cd automotive-frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Environment Setup**
   Create a `.env` file in the root directory:
   ```env
   # API Configuration
   VITE_API_BASE_URL=http://localhost:5000/api
   VITE_APP_ADMIN_DOMAIN=http://localhost:4100
   
   # App Configuration
   VITE_APP_NAME=Automotive Spare Parts
   VITE_APP_VERSION=1.0.0
   
   # Feature Flags
   VITE_ENABLE_ANALYTICS=true
   VITE_ENABLE_NOTIFICATIONS=true
   ```

4. **Start the development server**
   ```bash
   npm run dev
   # or
   yarn dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:4100`

## 📱 Pages & Features

### 🏠 Home Page
- **Hero Section**: Car search interface with cascading dropdowns
- **Current Offers**: Image slider with promotional offers
- **Brand Trust**: Scrolling brand logos
- **Search Functionality**: Global search with autocomplete

### 🚗 My Garage
- **Car Management**: Add, edit, and remove vehicles
- **Quick Search**: Find parts for specific vehicles
- **Vehicle History**: Track maintenance and orders

### 👤 User Account Pages
- **My Profile**: Personal information and preferences
- **My Orders**: Order history and tracking
- **My Wishlist**: Saved items and favorites
- **Addresses**: Shipping address management
- **Company/GST**: Business information for B2B customers
- **My Documents**: Document management and downloads

### 🛒 Shopping Features
- **Product Catalog**: Browse and filter products
- **Shopping Cart**: Add, remove, and update items
- **Search**: Advanced product search
- **Categories**: Organized product categories

## 🎨 UI Components

### Header Component
- **Logo**: Brand logo with home navigation
- **Search Bar**: Global product search
- **Navigation**: My Garage, Account, Wishlist, Cart
- **User Menu**: Profile dropdown with account options

### Car Search Modal
- **Cascading Dropdowns**: Maker → Model → Year → Variant
- **Comprehensive Database**: Major car brands and models
- **Quick Search**: Direct part search for specific vehicles

### Footer Component
- **Company Information**: Contact details and social links
- **Quick Links**: Important pages and resources
- **Social Media**: Facebook, Instagram, LinkedIn links

## 🔧 Development

### Available Scripts

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build

# Linting and Formatting
npm run lint         # Run ESLint
npm run lint:fix     # Fix ESLint issues
npm run format       # Format code with Prettier

# Testing
npm run test         # Run tests
npm run test:coverage # Run tests with coverage
```

### Code Structure

#### Component Organization
- **Pages**: Full page components in `/src/pages/`
- **Components**: Reusable components in `/src/components/`
- **Layout**: Layout components in `/src/layout/`
- **Hooks**: Custom hooks in `/src/hooks/`

#### State Management
- **Context API**: For global state (theme, sidebar, admin)
- **Redux**: For complex state management
- **Local State**: useState and useEffect for component state

#### Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Custom CSS**: Additional styles in `/src/assets/css/`
- **Responsive Design**: Mobile-first approach

## 🎯 Key Features

### Car Search Interface
```jsx
// Cascading dropdown system
const SearchSection = () => {
  const [selectedMaker, setSelectedMaker] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [selectedVariant, setSelectedVariant] = useState("");
  
  // Comprehensive car database
  const carData = {
    MARUTI: {
      Swift: { 2023: ["LXI", "VXI", "ZXI"] },
      Alto: { 2023: ["Std", "LXI", "VXI"] }
    },
    // ... more brands
  };
};
```

### Responsive Design
- **Mobile First**: Optimized for mobile devices
- **Breakpoints**: sm, md, lg, xl, 2xl
- **Flexible Layout**: Adapts to all screen sizes

### Performance Optimization
- **Lazy Loading**: Components loaded on demand
- **Code Splitting**: Automatic code splitting with Vite
- **Image Optimization**: Optimized images and lazy loading
- **Bundle Analysis**: Built-in bundle analyzer

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Route Protection**: Private routes for authenticated users
- **Input Validation**: Form validation and sanitization
- **XSS Protection**: Secure rendering of user content
- **CSRF Protection**: Cross-site request forgery protection

## 🌐 Internationalization

- **Multi-language Support**: Ready for multiple languages
- **RTL Support**: Right-to-left language support
- **Localization**: Date, number, and currency formatting
- **Translation Management**: Easy translation updates

## 📊 Analytics & Monitoring

- **Performance Monitoring**: Core Web Vitals tracking
- **User Analytics**: User behavior tracking
- **Error Tracking**: Error monitoring and reporting
- **Conversion Tracking**: E-commerce conversion tracking

## 🚀 Deployment

### Vercel Deployment
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy to Vercel
vercel --prod
```

### Environment Variables
```env
# Production Environment
VITE_API_BASE_URL=https://your-api-domain.com/api
VITE_APP_ADMIN_DOMAIN=https://your-frontend-domain.com
```

### Build Optimization
- **Tree Shaking**: Remove unused code
- **Minification**: Compress JavaScript and CSS
- **Asset Optimization**: Optimize images and fonts
- **Caching**: Proper cache headers

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the Regular License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)

## 🙏 Acknowledgments

- React team for the amazing framework
- Vite team for the fast build tool
- Tailwind CSS team for the utility-first CSS
- All contributors and testers

---

**Note**: This is a comprehensive automotive spare parts e-commerce frontend with modern React.js features, responsive design, and excellent user experience. Make sure to configure all environment variables before running in production.