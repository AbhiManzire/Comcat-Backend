import React from 'react';
import { Link, useLocation } from 'react-router-dom';

export const Navbar = () => {
  const location = useLocation();

  const navItems = [
    { path: '/myorder', label: 'My orders' },
    { path: '/myprofile', label: 'My profile' },
    { path: '/mywishlist', label: 'My Wishlists' },
    { path: '/addresses', label: 'Addresses' },
    { path: '/company_gst', label: 'Company/GST' },
    { path: '/garage', label: 'My garage' },
    { path: '/document', label: 'My documents' }
  ];

  return (
    <div className="flex space-x-8 border-b border-gray-300 pb-2">
      {navItems.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          className={`text-sm font-medium pb-2 px-1 ${
            location.pathname === item.path
              ? 'text-sky-500 border-b-2 border-sky-500'
              : 'text-gray-500 hover:text-sky-500'
          }`}
        >
          {item.label}
        </Link>
      ))}
    </div>
  );
};


