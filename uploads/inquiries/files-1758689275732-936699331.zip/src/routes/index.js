import { lazy } from "react";
// use lazy for better code splitting
const Dashboard = lazy(() => import("@/pages/Dashboard"));
const Attributes = lazy(() => import("@/pages/Attributes"));
const ChildAttributes = lazy(() => import("@/pages/ChildAttributes"));
const Products = lazy(() => import("@/pages/Products"));
const ProductDetails = lazy(() => import("@/pages/ProductDetails"));
const Category = lazy(() => import("@/pages/Category"));
const Banner = lazy(() => import("@/pages/Banner"));
const ChildCategory = lazy(() => import("@/pages/ChildCategory"));
const Staff = lazy(() => import("@/pages/Staff"));
const Customers = lazy(() => import("@/pages/Customers"));
const CustomerOrder = lazy(() => import("@/pages/CustomerOrder"));
const Orders = lazy(() => import("@/pages/Orders"));
const OrderInvoice = lazy(() => import("@/pages/OrderInvoice"));
const Coupons = lazy(() => import("@/pages/Coupons"));
// const Setting = lazy(() => import("@/pages/Setting"));
const Page404 = lazy(() => import("@/pages/404"));
const ComingSoon = lazy(() => import("@/pages/ComingSoon"));
const EditProfile = lazy(() => import("@/pages/EditProfile"));
const Languages = lazy(() => import("@/pages/Languages"));
const Currencies = lazy(() => import("@/pages/Currencies"));
const Setting = lazy(() => import("@/pages/Setting"));
const StoreHome = lazy(() => import("@/pages/StoreHome"));
const StoreSetting = lazy(() => import("@/pages/StoreSetting"));
const Notifications = lazy(() => import("@/pages/Notifications"));
const UsedSpares = lazy(() => import("@/pages/UsedSpares"));
const LuckyDraw = lazy(() => import("@/pages/LuckyDraw"));
const Vendor = lazy(()=>import("@/pages/Vendor"));

//  * ⚠ These are internal routes!
//  * They will be rendered inside the app, using the default `containers/Layout`.
//  * If you want to add a route to, let's say, a landing page, you should add
//  * it to the `App`'s router, exactly like `Login`, `CreateAccount` and other pages
//  * are routed.
//  *
//  * If you're looking for the links rendered in the SidebarContent, go to
//  * `routes/sidebar.js`
const routes = [
  {
    path: "/admin/dashboard",
    component: Dashboard,
  },
  {
    path: "/admin/products",
    component: Products,
  },
  {
    path: "/admin/attributes",
    component: Attributes,
  },
  {
    path: "/admin/attributes/:id",
    component: ChildAttributes,
  },
  {
    path: "/admin/product/:id",
    component: ProductDetails,
  },
  {
    path: "/admin/categories",
    component: Category,
  },
  {
    path: "/admin/banners",
    component: Banner,
  },
  {
    path: "/admin/languages",
    component: Languages,
  },
  {
    path: "/admin/currencies",
    component: Currencies,
  },
  {
    path: "/admin/categories/:id",
    component: ChildCategory,
  },
  {
    path: "/admin/customers",
    component: Customers,
  },
  {
    path: "/admin/customer-order/:id",
    component: CustomerOrder,
  },
  {
    path: "/admin/our-staff",
    component: Staff,
  },
  {
    path: "/admin/orders",
    component: Orders,
  },
  {
    path: "/admin/order/:id",
    component: OrderInvoice,
  },
  {
    path: "/admin/coupons",
    component: Coupons,
  },
  { path: "/admin/settings", component: Setting },
  {
    path: "/admin/store/customization",
    component: StoreHome,
  },
  {
    path: "/admin/store/store-settings",
    component: StoreSetting,
  },
  {
    path: "/admin/404",
    component: Page404,
  },
  {
    path: "/admin/coming-soon",
    component: ComingSoon,
  },
  {
    path: "/admin/edit-profile",
    component: EditProfile,
  },
  {
    path: "/admin/notifications",
    component: Notifications,
  },
  {
    path: "/admin/used-spares",
    component: UsedSpares,
  },
    { path: "/admin/lucky-draw", component: LuckyDraw },
    
    { path: "/admin/vendor", component: Vendor },

];
const routeAccessList = [
  { label: "Dashboard", value: "dashboard" },
  { label: "Products", value: "products" },
  { label: "Categories", value: "categories" },
  { label: "Banner", value: "banners" },
  { label: "Attributes", value: "attributes" },
  { label: "Coupons", value: "coupons" },
  { label: "Used Spares", value: "used-spares" },
  { label: "Lucky Draw", value: "lucky-draw" }, // ✅ added LuckyDraw access
    { label: "Vendor", value: "vendor" }, // ✅ added LuckyDraw access

  { label: "Customers", value: "customers" },
  { label: "Orders", value: "orders" },
  { label: "Staff", value: "our-staff" },
  { label: "Settings", value: "settings" },
  { label: "Languages", value: "languages" },
  { label: "Currencies", value: "currencies" },
  { label: "ViewStore", value: "store" },
  { label: "StoreCustomization", value: "customization" },
  { label: "StoreSettings", value: "store-settings" },
  { label: "Product Details", value: "product" },
  { label: "Order Invoice", value: "order" },
  { label: "Edit Profile", value: "edit-profile" },
  { label: "Customer Order", value: "customer-order" },
  { label: "Notification", value: "notifications" },
  { label: "Coming Soon", value: "coming-soon" },
];
export { routeAccessList, routes };
