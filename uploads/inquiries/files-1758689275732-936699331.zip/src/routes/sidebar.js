import {
  FiGrid,
  FiUsers,
  FiUser,
  FiCompass,
  FiSettings,
  FiSlack,
  FiGlobe,
  FiTarget,
} from "react-icons/fi";
/**
 * ⚠ These are used just to render the Sidebar!
 * You can include any link here, local or external.
 *
 * If you're looking to actual Router routes, go to
 * `routes/index.js`
 */
const sidebar = [
  {
    path: "/admin/dashboard", // the url
    icon: FiGrid, // icon
    name: "Dashboard", // name that appear in Sidebar
  },
  {
    icon: FiSlack,
    name: "Catalog",
    routes: [
      {
        path: "/admin/products",
        name: "Products",
      },
      {
        path: "/admin/categories",
        name: "Categories",
      },
      { path: "/admin/banners", name: "Banner" },
      {
        path: "/admin/attributes",
        name: "Attributes",
      },
      {
        path: "/admin/coupons",
        name: "Coupons",
      },
      {
        path: "/admin/used-spares", // ✅ Added Used Spares here
        name: "Used Spares",
      },
    ],
  },
  {
    path: "/admin/customers",
    icon: FiUsers,
    name: "Customers",
  },
  {
    path: "/admin/orders",
    icon: FiCompass,
    name: "Orders",
  },
  {
    path: "/admin/our-staff",
    icon: FiUser,
    name: "OurStaff",
  },
   {
    path: "/admin/vendor",
    icon: FiUser,
    name: "Vendors",
  },
  {
    path: "/admin/settings?settingTab=common-settings",
    icon: FiSettings,
    name: "Settings",
  },
  {
    icon: FiGlobe,
    name: "International",
    routes: [
      {
        path: "/admin/languages",
        name: "Languages",
      },
      {
        path: "/admin/currencies",
        name: "Currencies",
      },
    ],
  },
  {
    icon: FiTarget,
    name: "OnlineStore",
    routes: [
      {
        name: "ViewStore",
        path: "/",
        outside: "store",
      },
      {
        path: "/admin/store/customization",
        name: "StoreCustomization",
      },
      {
        path: "/admin/store/store-settings",
        name: "StoreSettings",
      },
    ],
  },
  {
    icon: FiSlack,
    name: "Pages",
    routes: [
      // submenu
      {
        path: "/admin/404",
        name: "404",
      },
      {
        path: "/admin/coming-soon",
        name: "Coming Soon",
      },
    ],
  },
];

export default sidebar;
