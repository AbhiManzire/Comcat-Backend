import React from 'react';
import { FaCar, FaSearch, FaHeart, FaShoppingCart } from 'react-icons/fa';
import { MdAccountCircle } from "react-icons/md";
import { IoReorderThreeOutline } from "react-icons/io5";
import { useHistory, useLocation } from "react-router-dom";
import logo from "./logo.png";

const CompanyGST = () => {
  const history = useHistory();
  const location = useLocation();

  const goToWishlist = () => history.push("/mywishlist");
  const goToCart = () => history.push("/cart");
  const goToHomePage = () => history.push("/");
  const goToGarage = () => history.push("/garage");

  const handleAccountChange = (e) => {
    const value = e.target.value;
    if (value !== "MY ACCOUNT" && value.startsWith("/")) {
      history.push(value);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="w-full bg-white shadow-md px-6 py-4">
        <div className="flex justify-between items-center">
          {/* Left: Logo + Search */}
          <div className="flex items-center gap-6">
            <img
              onClick={goToHomePage}
              src={logo}
              alt="Boodmo Logo"
              className="h-[70px] w-[150px] cursor-pointer object-contain"
            />

            <div className="flex bg-gray-100 rounded-lg overflow-hidden shadow-sm text-sm w-[400px] lg:w-[500px]">
              <input
                type="text"
                placeholder='Search: "Maruti Oil Filter"'
                className="flex-1 px-4 py-3 text-gray-700 text-base outline-none"
              />
              <button className="bg-sky-500 text-white px-5 flex items-center justify-center">
                <FaSearch className="text-lg" />
              </button>
            </div>
          </div>

          {/* Right: Links & Buttons */}
          <div className="flex items-center gap-6 text-gray-700 font-medium">
            <button 
              onClick={goToGarage}
              className="hover:text-gray-700 text-blue-950 flex items-center font-bold gap-1"
            >
              <FaCar className="text-sky-500" /> MY GARAGE
            </button>

            <div className="flex items-center gap-1">
              <MdAccountCircle className="text-sky-500 text-xl" />
              <select 
                onChange={handleAccountChange}
                className="font-bold text-sm px-3 py-1 border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
              >
                <option value="MY ACCOUNT">MY ACCOUNT</option>
                <option value="/myprofile">My Profile</option>
                <option value="/myorder">My Order</option>
                <option value="/document">Document</option>
                <option value="/company_gst">Company/GST</option>
                <option value="/addresses">Addresses</option>
                <option value="/mywishlist">My Wishlist</option>
              </select>
            </div>

            <button onClick={goToWishlist} className="hover:text-blue-700 hover:scale-110">
              <FaHeart className="text-blue-900 text-xl" />
            </button>

            <button onClick={goToCart} className="hover:text-blue-700 hover:scale-110">
              <FaShoppingCart className="text-blue-900 text-xl" />
            </button>

            <button className="hover:text-blue-700 text-2xl hover:scale-110">
              <IoReorderThreeOutline className="text-blue-900" />
            </button>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div className="px-6 py-4">
        <h1 className="text-3xl font-bold text-gray-800">
          Company/<span className="text-sky-500">GST</span>
        </h1>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-8 border-b border-gray-300 px-6 pb-2">
        <button 
          onClick={() => history.push("/myorder")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My orders
        </button>
        <button 
          onClick={() => history.push("/myprofile")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My profile
        </button>
        <button 
          onClick={() => history.push("/mywishlist")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My Wishlists
        </button>
        <button 
          onClick={() => history.push("/addresses")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Addresses
        </button>
        <button className="text-sm font-medium pb-2 px-1 text-sky-500 border-b-2 border-sky-500">
          Company/GST
        </button>
        <button 
          onClick={() => history.push("/garage")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My garage
        </button>
        <button 
          onClick={() => history.push("/document")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My documents
        </button>
      </div>

      {/* Main Content */}
      <div className="px-6 py-8">
        <h2 className="text-2xl text-cyan-800 font-semibold mb-6">
          Billing information
        </h2>

        <div className="bg-white shadow rounded-lg p-6 max-w-2xl">
          <form className="space-y-6">
            {/* Company name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Company name</label>
              <input
                type="text"
                className="w-full px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                placeholder="Enter company name"
              />
            </div>

            {/* Mobile */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Mobile</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  defaultValue="+91"
                  className="w-1/4 px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  readOnly
                />
                <input
                  type="text"
                  className="flex-1 px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="Enter mobile number"
                />
              </div>
            </div>

            {/* GST number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">GST number</label>
              <input
                type="text"
                className="w-full px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                placeholder="Enter GST number"
              />
            </div>

            {/* Checkbox */}
            <div className="flex items-center">
              <input
                type="checkbox"
                id="not-gst-registered"
                className="h-4 w-4 text-sky-600 focus:ring-sky-500 border-gray-300 rounded"
              />
              <label htmlFor="not-gst-registered" className="ml-2 block text-sm text-gray-700">
                My company is not GST registered
              </label>
            </div>

            {/* Address */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
              <textarea
                className="w-full px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                rows="4"
                placeholder="Enter address"
                maxLength="110"
              />
              <div className="text-right text-sm text-gray-500 mt-1">0/110</div>
            </div>

            {/* Pincode and Country */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Pincode</label>
                <input
                  type="text"
                  className="w-full px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  placeholder="Enter pincode"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                <input
                  type="text"
                  defaultValue="India"
                  className="w-full px-3 py-3 border rounded-lg bg-gray-100 text-gray-500"
                  readOnly
                />
              </div>
            </div>

            {/* Address Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Address Title (Optional)</label>
              <input
                type="text"
                className="w-full px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
                placeholder="Enter address title"
              />
            </div>

            {/* Save Button */}
            <div className="text-center">
              <button
                type="button"
                className="bg-sky-400 hover:bg-sky-500 text-white rounded py-4 px-8 font-semibold"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Support Tab */}
      <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-50">
        <div className="bg-red-500 text-white px-3 py-8 writing-mode-vertical-rl text-center cursor-pointer hover:bg-red-600 transition">
          Support
        </div>
      </div>
    </div>
  );
};

export default CompanyGST;
