import React, { useState } from "react";
import { FaDatabase, FaFacebook, FaApple } from "react-icons/fa";
import { FaCar, FaSearch, FaHeart, FaShoppingCart } from 'react-icons/fa';
import { MdAccountCircle } from "react-icons/md";
import { IoReorderThreeOutline } from "react-icons/io5";
import { CiCircleQuestion } from "react-icons/ci";
import { FcGoogle } from "react-icons/fc";
import { BiFingerprint } from "react-icons/bi";
import { useHistory, useLocation } from "react-router-dom";
import logo from "./logo.png";

const MyProfile = () => {
  const history = useHistory();
  const location = useLocation();
  const [toast, setToast] = useState("");
  const email = "fgfg@fgfg.vbn";

  const goToWishlist = () => history.push("/mywishlist");
  const goToCart = () => history.push("/cart");
  const goToHomePage = () => history.push("/");
  const goToGarage = () => history.push("/garage");

  const handleAccountChange = (e) => {
    const value = e.target.value;
    if (value !== "MY ACCOUNT" && value.startsWith("/")) {
      history.push(value);
    }
  };

  const showToast = (message) => {
    setToast(message);
    setTimeout(() => setToast(""), 2000);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(email);
    showToast("Email copied succesfully!");
  };

  const handleSavePhone = () => {
    showToast("Phone number saved!");
  };

  const handleChangePassword = () => {
    showToast(" Password change requested!");
  };

  const handleSaveProfile = () => {
    showToast("Profile saved!");
  };

  const handlePurchase = () => {
    showToast("Points purchased!");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {toast && (
        <div className="fixed top-5 right-5 bg-gray-900 text-white px-4 py-2 rounded-lg shadow-lg animate-fade-in-out">
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="w-full bg-white shadow-md px-6 py-4">
        <div className="flex justify-between items-center">
          {/* Left: Logo + Search */}
          <div className="flex items-center gap-6">
            <img
              onClick={goToHomePage}
              src={logo}
              alt="Boodmo Logo"
              className="h-[70px] w-[150px] cursor-pointer object-contain"
            />

            <div className="flex bg-gray-100 rounded-lg overflow-hidden shadow-sm text-sm w-[400px] lg:w-[500px]">
              <input
                type="text"
                placeholder='Search: "Maruti Alto Oil Filter"'
                className="flex-1 px-4 py-3 text-gray-700 text-base outline-none"
              />
              <button className="bg-sky-500 text-white px-5 flex items-center justify-center">
                <FaSearch className="text-lg" />
              </button>
            </div>
          </div>

          {/* Right: Links & Buttons */}
          <div className="flex items-center gap-6 text-gray-700 font-medium">
            <button 
              onClick={goToGarage}
              className="hover:text-gray-700 text-blue-950 flex items-center font-bold gap-1"
            >
              <FaCar className="text-sky-500" /> MY GARAGEaaaaaaaa
            </button>

            <div className="flex items-center gap-1">
              <MdAccountCircle className="text-sky-500 text-xl" />
              <select 
                onChange={handleAccountChange}
                className="font-bold text-sm px-3 py-1 border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
              >
                <option value="MY ACCOUNT">MY ACCOUNT</option>
                <option value="/myprofile">My Profile</option>
                <option value="/myorder">My Order</option>
                <option value="/document">Document</option>
                <option value="/company_gst">Company/GST</option>
                <option value="/addresses">Addresses</option>
                <option value="/mywishlist">My Wishlist</option>
              </select>
            </div>

            <button onClick={goToWishlist} className="hover:text-blue-700 hover:scale-110">
              <FaHeart className="text-blue-900 text-xl" />
            </button>

            <button onClick={goToCart} className="hover:text-blue-700 hover:scale-110">
              <FaShoppingCart className="text-blue-900 text-xl" />
            </button>

            <button className="hover:text-blue-700 text-2xl hover:scale-110">
              <IoReorderThreeOutline className="text-blue-900" />
            </button>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div className="px-6 py-4">
        <h1 className="text-3xl font-bold text-gray-800">
          My <span className="text-sky-500">Profile</span>
        </h1>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-8 border-b border-gray-300 px-6 pb-2">
        <button 
          onClick={() => history.push("/myorder")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My orders
        </button>
        <button className="text-sm font-medium pb-2 px-1 text-sky-500 border-b-2 border-sky-500">
          My profile
        </button>
        <button 
          onClick={() => history.push("/mywishlist")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My Wishlists
        </button>
        <button 
          onClick={() => history.push("/addresses")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Addresses
        </button>
        <button 
          onClick={() => history.push("/company_gst")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Company/GST
        </button>
        <button 
          onClick={() => history.push("/garage")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My garage
        </button>
        <button 
          onClick={() => history.push("/document")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My documents
        </button>
      </div>

      {/* Main Content */}
      <div className="px-6 py-8">
        <h2 className="text-2xl text-cyan-800 font-semibold mb-6">
          Personal Information
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Personal Information */}
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-700 mb-4">
              Personal Information
            </h2>

            <form className="space-y-4">
              <div>
                <div className="flex items-center gap-2">
                  <input
                    type="email"
                    defaultValue={email}
                    className="flex-1 px-3 py-3 border rounded-lg text-gray-400 focus:ring-2 focus:ring-sky-500"
                    readOnly
                  />
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="px-3 py-3 text-sm border rounded-lg text-sky-600 hover:bg-sky-50"
                  >
                    Copy
                  </button>
                </div>
              </div>

              {/* Name Fields */}
              <div className="flex gap-4">
                <input
                  type="text"
                  placeholder="First name"
                  className="w-1/2 px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500"
                />
                <input
                  type="text"
                  placeholder="Last name"
                  className="w-1/2 px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Notification Preferences */}
              <a href="#" className="text-sky-600 text-sm py-3 hover:underline">
                Notification preferences
              </a>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={handleChangePassword}
                  className="px-4 py-3 border rounded-lg hover:bg-sky-400"
                >
                  Change Password
                </button>
                <button
                  type="button"
                  onClick={handleSaveProfile}
                  className="px-6 py-3 rounded-lg bg-sky-500 text-white font-medium hover:bg-sky-600"
                >
                  Save
                </button>
              </div>
            </form>
          </div>

          {/* Phone Number Section */}
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-700 mb-4">
              Phone Number
            </h2>

            <div className="flex gap-2">
              <input
                type="text"
                defaultValue="+91"
                className="w-1/4 px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500"
                readOnly
              />
              <input
                type="text"
                placeholder="Phone"
                className="flex-1 px-3 py-3 border rounded-lg focus:ring-2 focus:ring-sky-500"
              />
              <button
                type="button"
                onClick={handleSavePhone}
                className="px-6 py-3 rounded-lg bg-sky-500 text-white font-medium hover:bg-sky-600"
              >
                Save
              </button>
            </div>
          </div>
        </div>

        {/* Points and Connections */}
        <div className="grid md:grid-cols-2 gap-8 mt-8">
          {/* boodmo Points */}
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-semibold text-blue-700 mb-4 flex items-center gap-2">
              boodmo Points <CiCircleQuestion />
            </h2>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FaDatabase className="text-2xl" />
                <span className="text-gray-800 font-medium">0 Points</span>
              </div>
            </div>
            <div className="flex gap-2">
              <select className="flex-1 px-3 py-3 border rounded-lg">
                <option>30 Points (₹2.3/point) - ₹69</option>
                <option>300 Points (₹ 1/point) - ₹299</option>
                <option>1000 Points (₹0.8/point) - ₹799</option>
                <option>5000 Points (₹0.7/point) - ₹3,499</option>
                <option>10000 Points (₹0.6/point) - ₹6,499</option>
                <option>30000 Points (₹0.5/point) - ₹15,999</option>
              </select>
              <button
                type="button"
                onClick={handlePurchase}
                className="px-4 py-3 rounded-lg bg-sky-500 text-white hover:bg-sky-600"
              >
                Purchase
              </button>
            </div>
            <a
              href="#"
              className="text-sky-600 text-sm hover:underline block mt-2"
            >
              Check usage history
            </a>
          </div>

          {/* Profile Connections */}
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-lg font-semibold text-blue-700 mb-4 flex items-center gap-2">
              Profile Connections <CiCircleQuestion />
            </h2>

            <div className="flex gap-6 text-3xl text-gray-600">
              <FcGoogle className="hover:scale-110 border transition cursor-pointer" />
              <FaFacebook className="hover:text-blue-600 hover:scale-110 border transition cursor-pointer" />
              <FaApple className="hover:text-black hover:scale-110 border transition cursor-pointer" />
              <BiFingerprint className="hover:text-sky-600 hover:scale-110 border transition cursor-pointer" />
            </div>
          </div>
        </div>
      </div>

      {/* Support Tab */}
      <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-50">
        <div className="bg-red-500 text-white px-3 py-8 writing-mode-vertical-rl text-center cursor-pointer hover:bg-red-600 transition">
          Support
        </div>
      </div>
    </div>
  );
};

export default MyProfile;