/**
 * ========================================
 * AUTOMOTIVE SPARE PARTS - HOME PAGE COMPONENT
 * ========================================
 * 
 * This is the main home page component for the Automotive Spare Parts e-commerce platform.
 * It includes:
 * - Header with navigation and search functionality
 * - Hero section with car search modal
 * - Current offers section with image slider
 * - Brand trust section with scrolling logos
 * - Footer with company information and social links
 * 
 * @author: Your Name
 * @version: 1.0.0
 * @created: 2024
 */

// React core imports
import React, { useState, useEffect } from "react";
import { useHistory, useLocation } from "react-router-dom";

// React Icons imports
import { FaSearch, FaCar, FaHeart, FaShoppingCart } from "react-icons/fa";
import { MdAccountCircle } from "react-icons/md";
import { IoReorderThreeOutline } from "react-icons/io5";
import { FaFacebookF, FaInstagram, FaLinkedinIn } from "react-icons/fa";

// Assets
import logo from "./logo.png";

/**
 * ========================================
 * CAR SEARCH SECTION COMPONENT
 * ========================================
 * 
 * This component provides a comprehensive car search interface that allows users to:
 * - Select car manufacturer (maker)
 * - Choose car model based on selected manufacturer
 * - Pick manufacturing year
 * - Select car modification/variant
 * 
 * The component uses cascading dropdowns where each selection filters the next options.
 * 
 * @component SearchSection
 * @returns {JSX.Element} Car search interface with cascading dropdowns
 */
const SearchSection = () => {
  // ========================================
  // STATE MANAGEMENT
  // ========================================
  
  // Selected values for each dropdown
  const [selectedMaker, setSelectedMaker] = useState("");      // Selected car manufacturer
  const [selectedModel, setSelectedModel] = useState("");     // Selected car model
  const [selectedYear, setSelectedYear] = useState("");       // Selected manufacturing year
  
  // Available options for each dropdown (populated based on previous selections)
  const [models, setModels] = useState([]);                    // Available models for selected maker
  const [years, setYears] = useState([]);                     // Available years for selected model
  const [modifications, setModifications] = useState([]);     // Available modifications for selected year

  // ========================================
  // CAR DATABASE
  // ========================================
  
  /**
   * Comprehensive car database containing:
   * - Car manufacturers (makers)
   * - Car models for each manufacturer
   * - Manufacturing years for each model
   * - Available modifications/variants for each year
   * 
   * Structure: Maker -> Model -> Year -> Modifications[]
   */
  const carData = {
    // Chevrolet models and variants
    CHEVROLET: {
      AVEO: { 2022: ["Base", "Mid"], 2023: ["Top", "RS"] },
      BEAT: { 2022: ["LS", "LT"], 2023: ["LTZ", "Diesel"] },
      CRUZE: { 2021: ["LT", "LTZ"], 2022: ["LTZ"] },
    },
    
    // Honda models and variants
    HONDA: {
      City: { 2021: ["SV", "V"], 2022: ["VX", "ZX"], 2023: ["ZX+", "Sport"] },
      Civic: { 2021: ["V", "VX"], 2022: ["ZX"], 2023: ["ZX+", "Type R"] },
      Amaze: { 2022: ["E", "S"], 2023: ["VX", "ZX"] },
    },
    
    // Maruti Suzuki models and variants
    MARUTI: {
      Swift: { 2021: ["LXI", "VXI"], 2022: ["ZXI", "ZXI+"], 2023: ["ZXI+", "Sport"] },
      Alto: { 2021: ["Std", "LXI"], 2022: ["VXI", "VXI+"], 2023: ["VXI+"] },
      Dzire: { 2022: ["LXI", "VXI"], 2023: ["ZXI", "ZXI+"] },
      Baleno: { 2022: ["Sigma", "Delta"], 2023: ["Zeta", "Alpha"] },
    },
    
    // Hyundai models and variants
    HYUNDAI: {
      Creta: { 2021: ["E", "S"], 2022: ["SX", "SX+"], 2023: ["SX+", "SX(O)"] },
      Venue: { 2022: ["E", "S"], 2023: ["SX", "SX(O)"] },
      i20: { 2021: ["Magna", "Sportz"], 2022: ["Asta", "Asta(O)"] },
    },
    
    // KIA models and variants
    KIA: {
      Seltos: { 2021: ["HTK+", "HTX"], 2022: ["HTX+", "GT Line"] },
      Sonet: { 2022: ["HTE", "HTK"], 2023: ["HTX", "HTX+"] },
    },
    
    // Tata models and variants
    TATA: {
      Nexon: { 2021: ["XE", "XM"], 2022: ["XZ", "XZ+"] },
      Harrier: { 2022: ["XE", "XZ"], 2023: ["XZ+", "XZA"] },
      Altroz: { 2022: ["XE", "XT"], 2023: ["XZ", "XZ+"] },
    },
    TOYOTA: {
      Fortuner: { 2021: ["GX", "VX"], 2022: ["ZX", "ZX(O)"] },
      Innova: { 2022: ["E", "G"], 2023: ["V", "Z"] },
    },
    FORD: {
      EcoSport: { 2021: ["Ambiente", "Trend"], 2022: ["Titanium", "Titanium+"] },
      Figo: { 2021: ["Trend", "Titanium"], 2022: ["Titanium+", "Sports"] },
    },
    NISSAN: {
      Magnite: { 2022: ["XE", "XL"], 2023: ["XV", "XV Premium"] },
      Kicks: { 2022: ["XL", "XV"], 2023: ["XV Premium", "XV Premium (O)"] },
    },
    RENAULT: {
      Kwid: { 2021: ["RXT", "RXL"], 2022: ["RXZ", "RXZ Opt"] },
      Duster: { 2021: ["RxE", "RxL"], 2022: ["RxZ", "RxZ Opt"] },
    },
  };

  const handleMakerChange = (e) => {
    const maker = e.target.value;
    setSelectedMaker(maker);
    setModels(maker ? Object.keys(carData[maker]) : []);
    setSelectedModel("");
    setSelectedYear("");
    setYears([]);
    setModifications([]);
  };

  const handleModelChange = (e) => {
    const model = e.target.value;
    setSelectedModel(model);
    setYears(model ? Object.keys(carData[selectedMaker][model]) : []);
    setSelectedYear("");
    setModifications([]);
  };

  const handleYearChange = (e) => {
    const year = e.target.value;
    setSelectedYear(year);
    setModifications(year ? carData[selectedMaker][selectedModel][year] : []);
  };

  return (
    <div className="text-left">
      <h2 className="text-2xl font-bold text-gray-800 mb-2">
        Add new <span className="text-sky-500">Car</span>
      </h2>
      <h2 className="text-lg mb-4">Find your car by Number Plate:</h2>

      <div className="flex items-center border rounded-lg px-3 py-2 shadow-md mb-4">
        <span className="bg-gray-200 px-3 py-2 rounded-l">IND</span>
        <input
          type="text"
          placeholder="DL1AA2345"
          className="flex-1 px-3 py-2 outline-none text-gray-700"
        />
        <FaSearch className="text-gray-500 text-xl cursor-pointer" />
      </div>

      <p className="text-gray-500 my-4">OR</p>

      {/* Dropdowns */}
      <div className="flex flex-col gap-3 mb-4">
        <select
          className="border px-4 py-2 rounded focus:ring-2 focus:ring-sky-500"
          value={selectedMaker}
          onChange={handleMakerChange}
        >
          <option value="">Select Car Maker</option>
          {Object.keys(carData).map((maker) => (
            <option key={maker} value={maker}>
              {maker}
            </option>
          ))}
        </select>

        <select
          className="border px-4 py-2 rounded focus:ring-2 focus:ring-sky-500"
          value={selectedModel}
          onChange={handleModelChange}
          disabled={!selectedMaker}
        >
          <option value="">Select Model</option>
          {models.map((model) => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
        </select>

        <select
          className="border px-4 py-2 rounded focus:ring-2 focus:ring-sky-500"
          value={selectedYear}
          onChange={handleYearChange}
          disabled={!selectedModel}
        >
          <option value="">Select Year</option>
          {years.map((year) => (
            <option key={year} value={year}>
              {year}
            </option>
          ))}
        </select>

        <select
          className="border px-4 py-2 rounded focus:ring-2 focus:ring-sky-500"
          disabled={!selectedYear}
        >
          <option value="">Select Modification</option>
          {modifications.map((mod) => (
            <option key={mod} value={mod}>
              {mod}
            </option>
          ))}
        </select>

        <input
          type="text"
          placeholder="Enter VIN"
          className="border px-4 py-2 rounded focus:ring-2 focus:ring-sky-500"
        />
      </div>

      <button className="bg-sky-500 font-bold hover:bg-sky-600 text-white px-8 py-3 shadow rounded w-full">
        Save
      </button>
    </div>
  );
};

// 🔹 Main Hero Section with Slideshow + Modal
const BoodmoUi = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImage, setCurrentImage] = useState(0);

  const images = [
    "https://boodmo.com/assets/images/board/min/engine-1-v2.png",
    "https://boodmo.com/assets/images/board/min/engine-2-v2.png",
    "https://boodmo.com/assets/images/board/min/engine-3-v2.png",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % images.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="bg-sky-300 px-20 flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="flex flex-col gap-6 px-4 w-full md:w-1/2">
        <div className="flex bg-white rounded-lg overflow-hidden shadow-md text-lg w-full">
          <input
            type="text"
            placeholder='Search: "Maruti Alto Oil Filter"'
            className="flex-1 px-4 py-4 outline-none text-gray-700"
          />
          <button className="bg-blue-900 text-white px-6 flex items-center justify-center">
            <FaSearch className="text-lg" />
          </button>
        </div>

        <button
          className="bg-blue-900 text-sm font-semibold text-white flex items-center justify-center gap-3 px-4 py-4 rounded-lg shadow-md hover:bg-blue-700 transition w-fit"
          onClick={() => setIsModalOpen(true)}
        >
          <FaCar className="text-2xl" />
          ADD CAR TO MY GARAGE
        </button>
      </div>

      <div className="w-full flex justify-center items-center">
        <img
          src={images[currentImage]}
          alt="Engine"
          className="h-80 md:h-96 object-contain transition-all duration-700"
        />
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white rounded-lg p-6 w-[90%] md:w-[50%] lg:w-[30%] shadow-lg relative">
            <button
              className="absolute top-3 right-3 text-gray-600 hover:text-black text-xl"
              onClick={() => setIsModalOpen(false)}
            >
              ✖
            </button>
            <SearchSection />
          </div>
        </div>
      )}
    </section>
  );
};

// 🔹 Current Offers Component
const CurrentOffers = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const offers = [
    "https://boodmo.com/media/images/slider/dd4ba16.webp",
    "https://boodmo.com/media/images/slider/8a7f220.webp",
    "https://boodmo.com/media/images/slider/e86b916.webp",
    "https://boodmo.com/media/images/slider/de458dc.webp",
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % offers.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [offers.length]);

  return (
    <section className="px-6 py-12">
      <h2 className="text-4xl font-bold text-gray-800 mb-6">
        Current <span className="text-sky-500">Offers</span>
      </h2>

      <div className="relative w-full">
        <div className="flex overflow-hidden rounded-lg">
          {offers.map((offer, index) => (
            <div
              key={index}
              className={`w-full flex-shrink-0 transition-transform duration-500 ${
                index === currentSlide ? "translate-x-0" : "translate-x-full"
              }`}
            >
              <img
                src={offer}
                className="rounded-lg shadow-md w-full h-64 object-cover"
                alt={`Offer ${index + 1}`}
              />
            </div>
          ))}
        </div>
        
        {/* Dots indicator */}
        <div className="flex justify-center mt-4 space-x-2">
          {offers.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full ${
                index === currentSlide ? "bg-sky-500" : "bg-gray-300"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// 🔹 Vehicle Search Section
const VehicleSearchSection = () => {
  const [selectedMaker, setSelectedMaker] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [models, setModels] = useState([]);
  const [years, setYears] = useState([]);
  const [modifications, setModifications] = useState([]);

  const carData = {
    CHEVROLET: {
      AVEO: { 2022: ["Base", "Mid"], 2023: ["Top"] },
      BEAT: { 2022: ["Base", "LS"], 2023: ["LT", "Diesel"] },
      CAPTIVA: { 2022: ["LT"], 2023: ["LTZ"] },
      CRUZE: { 2022: ["LT", "LTZ"], 2023: ["LTZ Plus"] },
    },
    HONDA: {
      City: { 2022: ["SV", "V"], 2023: ["VX", "ZX"] },
      Civic: { 2022: ["V", "VX"], 2023: ["ZX"] },
      Amaze: { 2022: ["E", "S"], 2023: ["VX"] },
    },
    MARUTI: {
      Swift: { 2022: ["LXI", "VXI"], 2023: ["ZXI", "ZXI+"] },
      Baleno: { 2022: ["Delta", "Zeta"], 2023: ["Alpha"] },
      WagonR: { 2022: ["LXI", "VXI"], 2023: ["ZXI"] },
      Alto: { 2022: ["Std", "LXI"], 2023: ["VXI+"] },
      Dzire: { 2022: ["LXI", "VXI"], 2023: ["ZXI"] },
    },
    HYUNDAI: {
      i20: { 2022: ["Magna", "Sportz"], 2023: ["Asta"] },
      Creta: { 2022: ["E", "EX"], 2023: ["SX", "SX(O)"] },
      Venue: { 2022: ["S", "SX"], 2023: ["N Line"] },
    },
    KIA: {
      Seltos: { 2022: ["HTE", "HTK"], 2023: ["GTX", "X-Line"] },
      Sonet: { 2022: ["HTE", "HTK"], 2023: ["GTX+"] },
    },
    TATA: {
      Nexon: { 2022: ["XE", "XM"], 2023: ["XZ", "XZ+"] },
      Harrier: { 2022: ["XT", "XZ"], 2023: ["XZ+"] },
      Safari: { 2022: ["XE", "XM"], 2023: ["XZ+"] },
      Tiago: { 2022: ["XE", "XM"], 2023: ["XZ+"] },
    },
    TOYOTA: {
      Innova: { 2022: ["GX", "VX"], 2023: ["Crysta", "ZX"] },
      Fortuner: { 2022: ["2.7 Petrol"], 2023: ["Legender"] },
    },
  };

  const handleMakerChange = (e) => {
    const maker = e.target.value;
    setSelectedMaker(maker);
    setModels(maker ? Object.keys(carData[maker]) : []);
    setSelectedModel("");
    setSelectedYear("");
    setYears([]);
    setModifications([]);
  };

  const handleModelChange = (e) => {
    const model = e.target.value;
    setSelectedModel(model);
    setYears(model ? Object.keys(carData[selectedMaker][model]) : []);
    setSelectedYear("");
    setModifications([]);
  };

  const handleYearChange = (e) => {
    const year = e.target.value;
    setSelectedYear(year);
    setModifications(year ? carData[selectedMaker][selectedModel][year] : []);
  };

  return (
    <section className="px-6 py-12 bg-gray-50">
      {/* Title */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-4xl font-bold text-gray-800">
          Search by <span className="text-sky-500">Vehicle</span>
        </h2>

        <div className="flex items-center space-x-2">
          <input
            type="text"
            placeholder="Search by number plate..."
            className="px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
          <button className="bg-sky-500 hover:bg-sky-600 text-white px-4 py-4 rounded-lg shadow">
            <FaSearch />
          </button>
        </div>
      </div>

      {/* Dropdowns */}
      <div className="flex flex-col md:flex-row items-center gap-4 bg-blue-900 p-4 rounded-lg shadow-md">
        {/* Car Maker */}
        <select
          className="border border-gray-300 px-4 py-2 rounded focus:ring-2 focus:ring-sky-500"
          value={selectedMaker}
          onChange={handleMakerChange}
        >
          <option value="">Select Car Maker</option>
          {Object.keys(carData).map((maker) => (
            <option key={maker} value={maker}>
              {maker}
            </option>
          ))}
        </select>

        {/* Model */}
        <select
          className={`border border-gray-300 px-4 py-2 rounded focus:ring-2 focus:ring-sky-500 ${
            !selectedMaker ? "text-gray-300 cursor-not-allowed" : ""
          }`}
          value={selectedModel}
          onChange={handleModelChange}
          disabled={!selectedMaker}
        >
          <option value="">Select Model Line</option>
          {models.map((model) => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
        </select>

        {/* Year */}
        <select
          className={`border border-gray-300 px-4 py-2 rounded focus:ring-2 focus:ring-sky-500 ${
            !selectedModel ? "text-gray-300 cursor-not-allowed" : ""
          }`}
          value={selectedYear}
          onChange={handleYearChange}
          disabled={!selectedModel}
        >
          <option value="">Select Year</option>
          {years.map((year) => (
            <option key={year} value={year}>
              {year}
            </option>
          ))}
        </select>

        {/* Modification */}
        <select
          className={`border border-gray-300 px-4 py-2 rounded focus:ring-2 focus:ring-sky-500 ${
            !selectedYear ? "text-gray-300 cursor-not-allowed" : ""
          }`}
          disabled={!selectedYear}
        >
          <option value="">Select Modification</option>
          {modifications.map((mod) => (
            <option key={mod} value={mod}>
              {mod}
            </option>
          ))}
        </select>

        {/* Search Button */}
        <button className="bg-sky-500 font-bold hover:bg-sky-600 text-white px-6 py-2 shadow rounded">
          Search Parts
        </button>
      </div>
    </section>
  );
};

// 🔹 Brand Trust and Car Makers
const BrandTrustAndCarMakers = () => {
  const brands = [
    { name: "PHC", logo: "https://boodmo.com/media/images/brand/4f106b0.webp" },
    { name: "DKMAX", logo: "https://boodmo.com/media/images/brand/ff1cc61.webp" },
    { name: "Elofic", logo: "https://boodmo.com/media/images/brand/6d1831f.webp" },
    { name: "Lemforder", logo: "https://boodmo.com/media/images/brand/987fd20.webp" },
    { name: "Sachs", logo: "https://boodmo.com/media/images/brand/1586c06.webp" },
    { name: "Spark Minda", logo: "https://boodmo.com/media/images/brand/6b0985f.webp" },
    { name: "EuroMac", logo: "https://boodmo.com/media/images/brand/7fab5d4.webp" },
    { name: "Shinshine", logo: "https://boodmo.com/media/images/brand/551a859.webp" },
    { name: "IGB", logo: "https://boodmo.com/media/images/brand/3408b8a.webp" },
    { name: "UNO Mind", logo: "https://boodmo.com/media/images/brand/e5b18f5.webp" },
    { name: "technix", logo: "https://boodmo.com/media/images/brand/52704b7.webp" },
    { name: "Valeo", logo: "https://boodmo.com/media/images/brand/af34236.webp" },
    { name: "Macklite", logo: "https://boodmo.com/media/images/brand/af34236.webp" },
    { name: "sc", logo: "https://boodmo.com/media/images/brand/a2c58ac.webp" },
    { name: "MGT", logo: "https://boodmo.com/media/images/brand/f50f113.webp" },
  ];

  const carMakers = [
    "MARUTI",
    "HYUNDAI",
    "MAHINDRA",
    "TATA",
    "CHEVROLET",
    "HONDA",
    "SKODA",
    "VW",
    "TOYOTA",
    "NISSAN",
    "RENAULT",
    "FORD",
    "FIAT",
    "KIA",
  ];

  return (
    <div className="px-6 py-12 bg-white">
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-4xl font-semibold text-gray-800">
            Brands we <span className="text-sky-400">Trust</span>
          </h2>
          <a href="#" className="text-sm text-blue-600 hover:underline">
            VIEW ALL
          </a>
        </div>

        <div className="overflow-hidden relative w-full">
          <div className="flex animate-scroll whitespace-nowrap">
            {brands.concat(brands).map((brand, index) => (
              <img
                key={index}
                src={brand.logo}
                alt={brand.name}
                className="h-12 mx-8 inline-block object-contain"
              />
            ))}
          </div>
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-4xl font-semibold text-gray-800">
            Popular <span className="text-sky-400">Car Makers</span>
          </h2>
          <a href="#" className="text-sm text-blue-600 hover:underline">
            VIEW ALL
          </a>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4 rounded">
          {carMakers.map((maker) => (
            <button
              key={maker}
              className="bg-white border border-gray-250 shadow-sm py-5 px-4 rounded-md text-sm font-medium hover:bg-gray-100 hover:shadow-lg"
            >
              {maker}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};

// 🔹 Header Component
const Header = () => {
  const history = useHistory();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const goToWishlist = () => history.push("/mywishlist");
  const goToCart = () => history.push("/cart");
  const goToHomePage = () => history.push("/");
  const goToGarage = () => history.push("/garage");

  const handleAccountChange = (e) => {
    const value = e.target.value;
    if (value !== "MY ACCOUNT" && value.startsWith("/")) {
      history.push(value);
    }
  };

  const isHomePage = location.pathname === "/";

  return (
    <div className="w-full bg-white shadow-md px-6 py-4 relative">
      <div className="flex justify-between items-center">
        {/* Left: Logo + Search */}
        <div className="flex items-center gap-6">
          <img
            onClick={goToHomePage}
            src={logo}
            alt="Boodmo Logo"
            className="h-[70px] w-[150px] cursor-pointer object-contain"
          />

          {!isHomePage && (
            <div className="flex bg-gray-100 rounded-lg overflow-hidden shadow-sm text-sm w-[450px] md:w-[600px]">
              <input
                type="text"
                placeholder='Search: "Maruti Alto Oil Filter"'
                className="flex-1 px-4 py-3 md:py-3 text-gray-700 text-base md:text-lg outline-none"
              />
              <button className="bg-sky-500 text-white px-5 flex items-center justify-center">
                <FaSearch className="text-lg md:text-xl" />
              </button>
            </div>
          )}
        </div>

        {/* Right: Links & Buttons */}
        <div className="flex items-center gap-6 text-gray-700 font-medium">
          <button 
            onClick={goToGarage}
            className="hover:text-gray-700 text-blue-950 flex items-center font-bold gap-1"
          >
            <FaCar className="text-sky-500" /> MY GARAGE
          </button>

          <div className="flex items-center gap-1">
            <MdAccountCircle className="text-sky-500 text-xl" />
            <select 
              onChange={handleAccountChange}
              className="font-bold text-sm px-3 py-1 border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
            >
              <option value="MY ACCOUNT">MY ACCOUNT</option>
              <option value="/myprofile">My Profile</option>
              <option value="/myorder">My Order</option>
              <option value="/document">Document</option>
              <option value="/company_gst">Company/GST</option>
              <option value="/addresses">Addresses</option>
              <option value="/mywishlist">My Wishlist</option>
            </select>
          </div>

          <button onClick={goToWishlist} className="hover:text-blue-700 hover:scale-110">
            <FaHeart className="text-blue-900 text-xl" />
          </button>

          <button onClick={goToCart} className="hover:text-blue-700 hover:scale-110">
            <FaShoppingCart className="text-blue-900 text-xl" />
          </button>

          <button
            onClick={() => setIsSidebarOpen(true)}
            className="hover:text-blue-700 text-2xl hover:scale-110"
          >
            <IoReorderThreeOutline className="text-blue-900" />
          </button>
        </div>
      </div>
    </div>
  );
};

// 🔹 Footer Component
const Footer = () => {
  return (
    <footer className="bg-white border-t mt-10 text-sm text-gray-600">
      <div className="max-w-7xl mx-auto px-4 py-10 sm:px-6 lg:px-8">
        <div className="bg-blue-700 text-white py-12">
          <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between">
            {/* Left text */}
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">Download</h2>
              <h3 className="text-2xl font-bold text-sky-400">Our Mobile App</h3>
              <p className="mt-2 text-gray-200">
                And get the full boodmo experience on the go
              </p>
            </div>

            {/* App Store & Play Store buttons */}
            <div className="flex gap-4">
              <a
                href="https://itunes.apple.com/in/app/id1154010647"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg"
                  alt="App Store"
                  className="h-12"
                />
              </a>
              <a
                href="https://play.google.com/store/apps/details?id=com.boodmo"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                  alt="Google Play"
                  className="h-12"
                />
              </a>
            </div>
          </div>
        </div>
        <div className="grid py-10 grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div>
            <div className="flex items-center mb-4">
              <img 
                src={logo} 
                alt="Boodmo Logo" 
                className="h-12 w-auto object-contain"
              />
            </div>
            <p className="mt-2 text-gray-600 text-l">
              India's biggest online marketplace for car spare parts
            </p>
          </div>

          {/* About links */}
          <div>
            <h3 className="text-base font-semibold text-blue-800 mb-2">About</h3>
            <ul className="space-y-5">
              {[
                "About us",
                "Contact us",
                "FAQ",
                "Careers",
                "Investor Relations",
                "Suppliers Relations",
                "Discovery Points",
                "boodmo API Solution",
                "Become a Vendor",
              ].map((link, i) => (
                <li key={i}>
                  <a href="#" className="hover:underline">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Policy links */}
          <div>
            <h3 className="text-base font-semibold text-blue-800 mb-2">Policy</h3>
            <ul className="space-y-5">
              {[
                "Return Policy",
                "Privacy Policy",
                "Disclaimer",
                "Terms of Use",
                "Buyers Policy",
                "Sellers Policy",
              ].map((link, i) => (
                <li key={i}>
                  <a href="#" className="hover:underline">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Useful links */}
          <div>
            <h3 className="text-base font-semibold text-blue-800 mb-2">Useful links</h3>
            <ul className="space-y-5">
              {[
                "Articles",
                "Brands",
                "Catalogues",
                "Car Makers",
                "Damaged Parts",
                "Best Offers",
                "Sitemap",
                "Sitemap2",
              ].map((link, i) => (
                <li key={i}>
                  <a href="#" className="hover:underline">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="flex mt-4 space-x-4 text-sky-400 text-xl py-10">
          <a href="#">
            <FaFacebookF />
          </a>
          <a href="#">
            <FaInstagram />
          </a>
          <a href="#">
            <FaLinkedinIn />
          </a>
        </div>
        {/* Bottom bar */}
        <div className="border-t mt-8 pt-4 text-center text-s text-gray-500">
          © 2015-2025 Smart Parts Online Pvt. Ltd. (v7.3.7 build 250715.1409)
        </div>
      </div>
    </footer>
  );
};

// 🔹 Main Home Page Component
const HomePage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <BoodmoUi />
      <CurrentOffers />
      <VehicleSearchSection />
      <BrandTrustAndCarMakers />
      <Footer />
    </div>
  );
};

export default HomePage;
