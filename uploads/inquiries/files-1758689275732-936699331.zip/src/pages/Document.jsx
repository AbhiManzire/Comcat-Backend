import React from 'react';
import { FaCar, FaSearch, FaHeart, FaShoppingCart } from 'react-icons/fa';
import { MdAccountCircle } from "react-icons/md";
import { IoReorderThreeOutline } from "react-icons/io5";
import { useHistory, useLocation } from "react-router-dom";
import logo from "./logo.png";

const Document = () => {
  const history = useHistory();
  const location = useLocation();

  const goToWishlist = () => history.push("/mywishlist");
  const goToCart = () => history.push("/cart");
  const goToHomePage = () => history.push("/");
  const goToGarage = () => history.push("/garage");

  const handleAccountChange = (e) => {
    const value = e.target.value;
    if (value !== "MY ACCOUNT" && value.startsWith("/")) {
      history.push(value);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="w-full bg-white shadow-md px-6 py-4">
        <div className="flex justify-between items-center">
          {/* Left: Logo + Search */}
          <div className="flex items-center gap-6">
            <img
              onClick={goToHomePage}
              src={logo}
              alt="Boodmo Logo"
              className="h-[70px] w-[150px] cursor-pointer object-contain"
            />

            <div className="flex bg-gray-100 rounded-lg overflow-hidden shadow-sm text-sm w-[400px] lg:w-[500px]">
              <input
                type="text"
                placeholder='Search: "Maruti Alto 2022 0.8L Oil Filter"'
                className="flex-1 px-4 py-3 text-gray-700 text-base outline-none"
              />
              <button className="bg-sky-500 text-white px-5 flex items-center justify-center">
                <FaSearch className="text-lg" />
              </button>
            </div>
          </div>

          {/* Right: Links & Buttons */}
          <div className="flex items-center gap-6 text-gray-700 font-medium">
            <button 
              onClick={goToGarage}
              className="hover:text-gray-700 text-blue-950 flex items-center font-bold gap-1"
            >
              <FaCar className="text-sky-500" /> MY GARAGE
            </button>

            <div className="flex items-center gap-1">
              <MdAccountCircle className="text-sky-500 text-xl" />
              <select 
                onChange={handleAccountChange}
                className="font-bold text-sm px-3 py-1 border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
              >
                <option value="MY ACCOUNT">MY ACCOUNT</option>
                <option value="/myprofile">My Profile</option>
                <option value="/myorder">My Order</option>
                <option value="/document">Document</option>
                <option value="/company_gst">Company/GST</option>
                <option value="/addresses">Addresses</option>
                <option value="/mywishlist">My Wishlist</option>
              </select>
            </div>

            <button onClick={goToWishlist} className="hover:text-blue-700 hover:scale-110">
              <FaHeart className="text-blue-900 text-xl" />
            </button>

            <button onClick={goToCart} className="hover:text-blue-700 hover:scale-110">
              <FaShoppingCart className="text-blue-900 text-xl" />
            </button>

            <button className="hover:text-blue-700 text-2xl hover:scale-110">
              <IoReorderThreeOutline className="text-blue-900" />
            </button>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div className="px-6 py-4">
        <h1 className="text-3xl font-bold text-gray-800">
          My <span className="text-sky-500">Documents</span>
        </h1>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-8 border-b border-gray-300 px-6 pb-2">
        <button 
          onClick={() => history.push("/myorder")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My orders
        </button>
        <button 
          onClick={() => history.push("/myprofile")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My profile
        </button>
        <button 
          onClick={() => history.push("/mywishlist")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My Wishlists
        </button>
        <button 
          onClick={() => history.push("/addresses")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Addresses
        </button>
        <button 
          onClick={() => history.push("/company_gst")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Company/GST
        </button>
        <button 
          onClick={() => history.push("/garage")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My garage
        </button>
        <button className="text-sm font-medium pb-2 px-1 text-sky-500 border-b-2 border-sky-500">
          My documents
        </button>
      </div>

      {/* Filters */}
      <div className="px-6 py-6">
        <div className="flex flex-wrap gap-4 items-center">
          <select className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none">
            <option>All Documents</option>
            <option>Invoices</option>
            <option>Receipts</option>
            <option>Warranties</option>
          </select>
          
          <select className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none">
            <option>10 per page</option>
            <option>20 per page</option>
            <option>50 per page</option>
          </select>

          <input
            type="date"
            className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
            placeholder="From date"
          />

          <input
            type="date"
            className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-sky-500 focus:outline-none"
            placeholder="To date"
          />

          <button className="bg-sky-400 hover:bg-sky-500 text-white px-6 py-2 rounded-lg font-semibold">
            Apply
          </button>

          <button className="border border-sky-500 text-sky-500 hover:bg-sky-50 px-6 py-2 rounded-lg font-semibold">
            Export
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col justify-center items-center min-h-[40vh] text-center px-6 py-20">
        <h2 className="text-cyan-800 font-semibold text-2xl mb-4">
          No items found
        </h2>
      </div>

      {/* Footer */}
      <div className="bg-blue-700 text-white py-12 mt-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0">
            <h2 className="text-2xl font-bold">Download</h2>
            <h3 className="text-2xl font-bold text-sky-400">Our Mobile App</h3>
            <p className="mt-2 text-gray-200">
              And get the full boodmo experience on the go
            </p>
          </div>
          <div className="flex gap-4">
            <a
              href="https://itunes.apple.com/in/app/id1154010647"
              target="_blank"
              rel="noopener noreferrer"
            >
              <img
                src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg"
                alt="App Store"
                className="h-12"
              />
            </a>
            <a
              href="https://play.google.com/store/apps/details?id=com.boodmo"
              target="_blank"
              rel="noopener noreferrer"
            >
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                alt="Google Play"
                className="h-12"
              />
            </a>
          </div>
        </div>
      </div>

      {/* Support Tab */}
      <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-50">
        <div className="bg-red-500 text-white px-3 py-8 writing-mode-vertical-rl text-center cursor-pointer hover:bg-red-600 transition">
          Support
        </div>
      </div>
    </div>
  );
};

export default Document;