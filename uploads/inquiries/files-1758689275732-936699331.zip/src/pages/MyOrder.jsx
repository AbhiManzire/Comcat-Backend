import React, { useState } from 'react';


import { FaCar, FaSearch, FaHeart, FaShoppingCart } from 'react-icons/fa';
import { MdAccountCircle } from "react-icons/md";
import { IoReorderThreeOutline } from "react-icons/io5";
import { useHistory, useLocation } from "react-router-dom";
import logo from "./logo.png";

const MyOrder = () => {
  const history = useHistory();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState("In-Progress");

  const goToWishlist = () => history.push("/mywishlist");
  const goToCart = () => history.push("/cart");
  const goToHomePage = () => history.push("/");
  const goToGarage = () => history.push("/garage");

  const handleAccountChange = (e) => {
    const value = e.target.value;
    if (value !== "MY ACCOUNT" && value.startsWith("/")) {
      history.push(value);
    }
  };

  const tabs = ["In-Progress", "Delivered", "Returned", "Cancelled"];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="w-full bg-white shadow-md px-6 py-4">
        <div className="flex justify-between items-center">
          {/* Left: Logo + Search */}
          <div className="flex items-center gap-6">
            <img
              onClick={goToHomePage}
              src={logo}
              alt="Boodmo Logo"
              className="h-[70px] w-[150px] cursor-pointer object-contain"
            />

            <div className="flex bg-gray-100 rounded-lg overflow-hidden shadow-sm text-sm w-[400px] lg:w-[500px]">
              <input
                type="text"
                placeholder='Search: "Maruti Alto Oil Filter"'
                className="flex-1 px-4 py-3 text-gray-700 text-base outline-none"
              />
              <button className="bg-sky-500 text-white px-5 flex items-center justify-center">
                <FaSearch className="text-lg" />
              </button>
            </div>
          </div>

          {/* Right: Links & Buttons */}
          <div className="flex items-center gap-6 text-gray-700 font-medium">
            <button 
              onClick={goToGarage}
              className="hover:text-gray-700 text-blue-950 flex items-center font-bold gap-1"
            >
              <FaCar className="text-sky-500" /> MY GARAGE
            </button>

            <div className="flex items-center gap-1">
              <MdAccountCircle className="text-sky-500 text-xl" />
              <select 
                onChange={handleAccountChange}
                className="font-bold text-sm px-3 py-1 border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
              >
                <option value="MY ACCOUNT">MY ACCOUNT</option>
                <option value="/myprofile">My Profile</option>
                <option value="/myorder">My Order</option>
                <option value="/document">Document</option>
                <option value="/company_gst">Company/GST</option>
                <option value="/addresses">Addresses</option>
                <option value="/mywishlist">My Wishlist</option>
              </select>
            </div>

            <button onClick={goToWishlist} className="hover:text-blue-700 hover:scale-110">
              <FaHeart className="text-blue-900 text-xl" />
            </button>

            <button onClick={goToCart} className="hover:text-blue-700 hover:scale-110">
              <FaShoppingCart className="text-blue-900 text-xl" />
            </button>

            <button className="hover:text-blue-700 text-2xl hover:scale-110">
              <IoReorderThreeOutline className="text-blue-900" />
            </button>
          </div>
        </div>
      </div>

      {/* Page Title */}
      <div className="px-6 py-4">
        <h1 className="text-3xl font-bold text-gray-800">
          My <span className="text-sky-500">Orders</span>
        </h1>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-8 border-b border-gray-300 px-6 pb-2">
        <button className="text-sm font-medium pb-2 px-1 text-sky-500 border-b-2 border-sky-500">
          My orders
        </button>
        <button 
          onClick={() => history.push("/myprofile")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My profile
        </button>
        <button 
          onClick={() => history.push("/mywishlist")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My Wishlists
        </button>
        <button 
          onClick={() => history.push("/addresses")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Addresses
        </button>
        <button 
          onClick={() => history.push("/company_gst")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          Company/GST
        </button>
        <button 
          onClick={() => history.push("/garage")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My garage
        </button>
        <button 
          onClick={() => history.push("/document")}
          className="text-sm font-medium pb-2 px-1 text-gray-500 hover:text-sky-500"
        >
          My documents
        </button>
      </div>

      {/* Order Status Tabs */}
      <div className="flex space-x-10 border-b border-gray-300 px-6 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab} 
            onClick={() => setActiveTab(tab)}
            className={`pb-2 px-1 font-medium ${activeTab === tab
              ? "text-sky-500 border-b-2 border-sky-500"
              : "text-gray-500 hover:text-sky-500"
              }`}
          >
            {tab} (0)
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex flex-col items-center justify-center text-center py-20 bg-white rounded-xl shadow-sm mx-6">
        <p className="text-gray-600 text-lg mb-4">
          No {activeTab} orders
        </p>
        <button className="bg-sky-400 hover:bg-sky-500 text-white px-6 py-4 rounded-md transition">
          Continue shopping
        </button>
      </div>

      {/* Support Tab */}
      <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-50">
        <div className="bg-red-500 text-white px-3 py-8 writing-mode-vertical-rl text-center cursor-pointer hover:bg-red-600 transition">
          Support
        </div>
      </div>
    </div>
  );
};

export default MyOrder;
