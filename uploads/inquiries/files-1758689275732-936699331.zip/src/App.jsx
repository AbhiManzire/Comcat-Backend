/**
 * ========================================
 * AUTOMOTIVE SPARE PARTS - MAIN APP COMPONENT
 * ========================================
 * 
 * This is the main application component that handles:
 * - Application routing (public and private routes)
 * - Lazy loading of components for better performance
 * - Toast notifications setup
 * - Authentication routing
 * 
 * @author: Your Name
 * @version: 1.0.0
 * @created: 2024
 */

// React core imports
import React, { lazy } from "react";

// Third-party imports
import { ToastContainer } from "react-toastify"; // For toast notifications
import {
  BrowserRouter as Router,  // Main router component
  Switch,                   // Route switching component
  Route,                    // Individual route component
  Redirect,                 // Redirect component
} from "react-router-dom";

// Custom component imports
import AccessibleNavigationAnnouncer from "@/components/AccessibleNavigationAnnouncer";
import PrivateRoute from "@/components/login/PrivateRoute";

// ========================================
// LAZY LOADED COMPONENTS
// ========================================
// Using lazy loading to improve initial page load performance
// Components are only loaded when their routes are accessed

// Admin Layout (Protected Route)
const Layout = lazy(() => import("@/layout/Layout"));

// Authentication Pages (Public Routes)
const Login = lazy(() => import("@/pages/Login"));
const SignUp = lazy(() => import("@/pages/SignUp"));
const ForgetPassword = lazy(() => import("@/pages/ForgotPassword"));
const ResetPassword = lazy(() => import("@/pages/ResetPassword"));

// Customer Pages (Public Routes)
const HomePage = lazy(() => import("@/pages/HomePage"));
const Garage = lazy(() => import("@/pages/Garage"));
const MyProfile = lazy(() => import("@/pages/MyProfile"));
const MyOrder = lazy(() => import("@/pages/MyOrder"));
const MyWishlist = lazy(() => import("@/pages/MyWishlist"));
const Cart = lazy(() => import("@/pages/Cart"));
const Document = lazy(() => import("@/pages/Document"));
const Addresses = lazy(() => import("@/pages/Addresses"));
const CompanyGST = lazy(() => import("@/pages/CompanyGST"));

/**
 * ========================================
 * MAIN APP COMPONENT
 * ========================================
 * 
 * This component renders the entire application with:
 * - Toast notification container
 * - Router for navigation
 * - Public routes (accessible to all users)
 * - Private routes (admin panel - requires authentication)
 * 
 * @returns {JSX.Element} The main application component
 */
const App = () => {
  return (
    <>
      {/* Toast Notification Container */}
      {/* Displays success, error, and info messages throughout the app */}
      <ToastContainer />
      
      {/* Main Router Component */}
      <Router>
        {/* Accessibility component for screen readers */}
        <AccessibleNavigationAnnouncer />
        
        {/* Route Switch - handles all application routing */}
        <Switch>
          {/* ========================================
               PUBLIC ROUTES (Customer-facing)
               ======================================== */}
          
          {/* Home Page Routes */}
          <Route exact path="/" component={HomePage} />
          <Route path="/home" component={HomePage} />
          
          {/* Customer Account Pages */}
          <Route path="/garage" component={Garage} />           {/* My Garage - Car management */}
          <Route path="/myprofile" component={MyProfile} />    {/* User Profile Management */}
          <Route path="/myorder" component={MyOrder} />          {/* Order History & Tracking */}
          <Route path="/mywishlist" component={MyWishlist} />    {/* Wishlist Management */}
          <Route path="/cart" component={Cart} />               {/* Shopping Cart */}
          <Route path="/document" component={Document} />       {/* Document Management */}
          <Route path="/addresses" component={Addresses} />      {/* Address Management */}
          <Route path="/company_gst" component={CompanyGST} />   {/* Business/GST Information */}
          
          {/* Authentication Pages */}
          <Route path="/login" component={Login} />             {/* User Login */}
          <Route path="/signup" component={SignUp} />            {/* User Registration */}
          <Route path="/forgot-password" component={ForgetPassword} />  {/* Password Reset Request */}
          <Route path="/reset-password/:token" component={ResetPassword} />  {/* Password Reset Form */}
          
          {/* ========================================
               PRIVATE ROUTES (Admin Panel)
               ======================================== */}
          
          {/* Admin Panel - Protected by authentication */}
          <PrivateRoute>
            <Route path="/admin" component={Layout} />
          </PrivateRoute>
          
          {/* Admin Default Redirect */}
          <Redirect from="/admin" to="/admin/dashboard" />
        </Switch>
      </Router>
    </>
  );
};

export default App;
