<?php 
/**
 * Welcome to Wonderkids Sections 2
 */
return array(
	'title'      => esc_html__( 'Welcome to WonderKids Sections 2', 'wonderkids-fse' ),
	'categories' => array( 'wonderkids-fse', 'Welcome to WonderKids Sections 2' ),
	'content'    => '<!-- wp:group {"className":"fse-sections-02","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","right":"var:preset|spacing|50","left":"var:preset|spacing|50"}}},"backgroundColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group fse-sections-02 has-foreground-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"className":"welcome-wrap","layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group welcome-wrap"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"48%","className":"welcome-left-part"} -->
<div class="wp-block-column welcome-left-part" style="flex-basis:48%"><!-- wp:image {"id":3076,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/wk-welcome-image.png" alt="" class="wp-image-3076"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"4%"} -->
<div class="wp-block-column" style="flex-basis:4%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"48%","className":"welcome-right-50","style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}}} -->
<div class="wp-block-column welcome-right-50" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:48%"><!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"600","fontSize":"22px"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}},"color":{"text":"#ff6666"}},"fontFamily":"poppins"} -->
<h5 class="wp-block-heading has-text-color has-poppins-font-family" style="color:#ff6666;margin-bottom:var(--wp--preset--spacing--40);font-size:22px;font-style:normal;font-weight:600;line-height:1.2">Welcome To WonderKids</h5>
<!-- /wp:heading -->

<!-- wp:heading {"className":"About-head","style":{"typography":{"fontSize":"44px","lineHeight":"1.0","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|50"}},"color":{"text":"#161616"}},"fontFamily":"poppins"} -->
<h2 class="wp-block-heading About-head has-text-color has-poppins-font-family" style="color:#161616;margin-bottom:var(--wp--preset--spacing--50);font-size:44px;font-style:normal;font-weight:600;line-height:1.0">We Are Here to Bring<br>YourChild Next Level</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}},"typography":{"lineHeight":"1.7","fontSize":"17px"}},"textColor":"body-text","fontFamily":"poppins"} -->
<p class="has-body-text-color has-text-color has-poppins-font-family" style="margin-bottom:var(--wp--preset--spacing--50);font-size:17px;line-height:1.7">Pellentesque habitant morb tristique senectus netus malesu ada faes ac turpis egestas. Vivamus imperdiet rutrumhicula. Mauris ornare turpis diam, sed commodo nunc susci pitacyi and Mauris ut ultricies turpis.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns" style="margin-bottom:var(--wp--preset--spacing--70)"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0"},"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40);padding-top:0;padding-bottom:0"><!-- wp:image {"id":3088,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-01.png" alt="" class="wp-image-3088"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"}},"textColor":"heading"} -->
<p class="has-heading-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:500">Expert Trainers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"wk-row2","style":{"spacing":{"padding":{"top":"0","bottom":"0"},"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group wk-row2" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40);padding-top:0;padding-bottom:0"><!-- wp:image {"id":3089,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-02.png" alt="" class="wp-image-3089"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"}},"textColor":"heading"} -->
<p class="has-heading-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:500">Expert Trainers</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"wk-row3","style":{"spacing":{"padding":{"top":"0","bottom":"0"},"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group wk-row3" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40);padding-top:0;padding-bottom:0"><!-- wp:image {"id":3097,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-03.png" alt="" class="wp-image-3097"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"}},"textColor":"heading"} -->
<p class="has-heading-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:500">Online Learning</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0"},"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--40);margin-bottom:var(--wp--preset--spacing--40);padding-top:0;padding-bottom:0"><!-- wp:image {"id":3098,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-04.png" alt="" class="wp-image-3098"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"}},"textColor":"heading"} -->
<p class="has-heading-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:500">Great Results</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"textColor":"foreground","style":{"color":{"background":"#191e24"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"padding":{"left":"var:preset|spacing|70","right":"var:preset|spacing|70","top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-foreground-color has-text-color has-background has-link-color wp-element-button" style="background-color:#191e24;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);