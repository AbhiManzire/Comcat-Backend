<?php
/**
 * Services We Provide Sections 1
 */
return array(
	'title'      => esc_html__( 'Services We Provide Sections 1 ', 'wonderkids-fse' ),
	'categories' => array( 'wonderkids-fse', 'Services We Provide Sections 1' ),
	'content'    => '<!-- wp:group {"className":"fse-sections-01","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"backgroundColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group fse-sections-01 has-foreground-background-color has-background" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)"><!-- wp:heading {"textAlign":"center","level":5,"style":{"typography":{"fontSize":"21px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#ff6666"},"elements":{"link":{"color":{"text":"#ff6666"}}},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontFamily":"poppins"} -->
<h5 class="wp-block-heading has-text-align-center has-text-color has-link-color has-poppins-font-family" style="color:#ff6666;margin-top:0;margin-bottom:0;font-size:21px;font-style:normal;font-weight:600">Service We Provide</h5>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"41px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#161616"},"elements":{"link":{"color":{"text":"#161616"}}},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|80"}}},"fontFamily":"poppins"} -->
<h2 class="wp-block-heading has-text-align-center has-text-color has-link-color has-poppins-font-family" style="color:#161616;margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--80);font-size:41px;font-style:normal;font-weight:600">Providing Good Qualities For<br>Your Loving Kids</h2>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--50)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"quality-servicesBX","style":{"color":{"background":"#75ce36"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50","top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"border":{"radius":"25px"}},"textColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group quality-servicesBX has-foreground-color has-text-color has-background has-link-color" style="border-radius:25px;background-color:#75ce36;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"id":3052,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"border":{"radius":"100%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/wk-services-img-01.jpg" alt="" class="wp-image-3052" style="border-radius:100%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"18px"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h4 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="font-size:18px">Learning &amp; Fun</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"}},"fontFamily":"poppins"} -->
<p class="has-text-align-center has-poppins-font-family" style="font-size:16px">Pllentesque habitant mtristique senectus netus esu ada faes ac tuivam imperdiet rutrumhla.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"quality-servicesBX","style":{"color":{"background":"#d766ff"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50","top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"border":{"radius":"25px"}},"textColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group quality-servicesBX has-foreground-color has-text-color has-background has-link-color" style="border-radius:25px;background-color:#d766ff;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"id":3070,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"border":{"radius":"100%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/wk-services-img-02.jpg" alt="" class="wp-image-3070" style="border-radius:100%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"18px"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h4 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="font-size:18px">Healthy Meals</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"}},"fontFamily":"poppins"} -->
<p class="has-text-align-center has-poppins-font-family" style="font-size:16px">Pllentesque habitant mtristique senectus netus esu ada faes ac tuivam imperdiet rutrumhla.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"quality-servicesBX","style":{"color":{"background":"#ffb132"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50","top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"border":{"radius":"25px"}},"textColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group quality-servicesBX has-foreground-color has-text-color has-background has-link-color" style="border-radius:25px;background-color:#ffb132;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"id":3071,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"border":{"radius":"100%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/wk-services-img-03.jpg" alt="" class="wp-image-3071" style="border-radius:100%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"18px"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h4 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="font-size:18px">Children Safety</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"}},"fontFamily":"poppins"} -->
<p class="has-text-align-center has-poppins-font-family" style="font-size:16px">Pllentesque habitant mtristique senectus netus esu ada faes ac tuivam imperdiet rutrumhla.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"quality-servicesBX","style":{"color":{"background":"#ff6666"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"padding":{"right":"var:preset|spacing|50","left":"var:preset|spacing|50","top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}},"border":{"radius":"25px"}},"textColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group quality-servicesBX has-foreground-color has-text-color has-background has-link-color" style="border-radius:25px;background-color:#ff6666;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"id":3072,"sizeSlug":"full","linkDestination":"none","align":"center","style":{"border":{"radius":"100%"}}} -->
<figure class="wp-block-image aligncenter size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/wk-services-img-04.jpg" alt="" class="wp-image-3072" style="border-radius:100%"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"18px"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground","fontFamily":"poppins"} -->
<h4 class="wp-block-heading has-text-align-center has-foreground-color has-text-color has-link-color has-poppins-font-family" style="font-size:18px">Cute Environment</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"}},"fontFamily":"poppins"} -->
<p class="has-text-align-center has-poppins-font-family" style="font-size:16px">Pllentesque habitant mtristique senectus netus esu ada faes ac tuivam imperdiet rutrumhla.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);