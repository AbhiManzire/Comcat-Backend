=== WonderKids FSE ===
Contributors: gracethemes
Tags:blog, news, one-column, two-columns, right-sidebar, block-styles, custom-colors, editor-style, custom-background, custom-menu, featured-images, template-editing, full-site-editing, block-patterns,  threaded-comments, wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.6
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The WonderKids FSE is a free nursery school WordPress theme for primary schools, universities, academy, secondary school, LMS, training center and educational institutions. WonderKids FSE comes with a highly attractive yet sophisticated visual appeal that is perfectly designed to cater to a nursery website. It comes with high functionality and performance to provide users with the best website performance. It is a WooCommerce-friendly theme. Besides WooCommerce, many other popular plugins are compatible with this free Nursery School WordPress Theme, making it a complete website solution for all sorts of educational websites. You can effortlessly run it on various browsing platforms like Google, Yahoo, Bing, Mozilla Firefox, Chrome, etc, without encountering a single issue. Simultaneously, this theme can be operated on multiple devices like laptops, PCs, tablets, etc. Moreover, WonderKids FSE has qualified for Google's Mobile-friendly test; therefore, you will have no issue at all in operating it on your mobile phone. Being 100% retina-ready, this theme can deliver excellent quality visuals to make your nursery website stand out. If you use this theme for your website, you will be easily able to build a strong online presence in no time!

== Theme License & Copyright == 

* WonderKids FSE WordPress Theme, Copyright 2024 Grace Themes 
* WonderKids FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

== Resources ==

Theme is Built using the following resource bundles.

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/591151 ( Header Banner image)



= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1370725 (sections 4 column 1 image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1661298  (sections 4 column 2 image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/774210  (sections 4 column 3 image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/760305  (sections 4 column 4 image)


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/57604  (Welcome to image 1)


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/546778  (Welcome to image 2)


= Icon Images =

  * Grace Themes Self Designed icons images:	
	assets/images/icon-01.png
	assets/images/icon-02.png
	assets/images/icon-03.png
	assets/images/icon-04.png
	assets/images/welcome-shapesbg.png
	assets/images/wk-icon-clock.png
	assets/images/wk-icon-map.png
	assets/images/wk-icon-phone.png	

    
For any help you can mail us at support@gracethemes.com